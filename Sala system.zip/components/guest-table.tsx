'use client';

import { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  MessageCircle,
  Star,
  Trash2,
  Users,
  Clock,
} from 'lucide-react';
import type { Guest, GuestStatus } from '@/lib/types';
import { StatusDropdown } from './status-dropdown';
import { ConfirmationModal } from './confirmation-modal';

interface GuestTableProps {
  guests: Guest[];
  onStatusChange: (id: string, status: GuestStatus) => void;
  onDelete: (id: string) => void;
}

function formatWaitTime(addedAt: number): { ar: string; en: string } {
  const minutes = Math.floor((Date.now() - addedAt) / 60000);
  if (minutes < 1) return { ar: 'أقل من دقيقة', en: 'Less than a minute' };
  return {
    ar: `${minutes} دقيقة`,
    en: `${minutes} Minutes`,
  };
}

export function GuestTable({ guests, onStatusChange, onDelete }: GuestTableProps) {
  const [confirmAction, setConfirmAction] = useState<{
    type: 'delete' | 'notify' | 'rate';
    guestId: string;
    guestName: string;
  } | null>(null);

  const handleNotify = (guest: Guest) => {
    if (!guest.phone) {
      alert('لا يوجد رقم جوال / No phone number available');
      return;
    }
    const message = encodeURIComponent(
      `مرحباً ${guest.name}، دورك قريب في SALA Laser Tag! يرجى الاستعداد.`
    );
    window.open(`https://wa.me/966${guest.phone.replace(/^0/, '')}?text=${message}`, '_blank');
  };

  const handleRateUs = (guest: Guest) => {
    if (!guest.phone) {
      alert('لا يوجد رقم جوال / No phone number available');
      return;
    }
    const message = encodeURIComponent(
      `شكراً لزيارتك SALA Laser Tag! ⭐ نتمنى أن تكون تجربتك ممتعة. يسعدنا تقييمك: [رابط التقييم]`
    );
    window.open(`https://wa.me/966${guest.phone.replace(/^0/, '')}?text=${message}`, '_blank');
  };

  const executeAction = () => {
    if (!confirmAction) return;

    switch (confirmAction.type) {
      case 'delete':
        onDelete(confirmAction.guestId);
        break;
      case 'notify':
        const notifyGuest = guests.find((g) => g.id === confirmAction.guestId);
        if (notifyGuest) handleNotify(notifyGuest);
        break;
      case 'rate':
        const rateGuest = guests.find((g) => g.id === confirmAction.guestId);
        if (rateGuest) handleRateUs(rateGuest);
        break;
    }
    setConfirmAction(null);
  };

  const getConfirmationText = () => {
    switch (confirmAction?.type) {
      case 'delete':
        return {
          title: { ar: 'حذف الضيف', en: 'Delete Guest' },
          description: {
            ar: `هل أنت متأكد من حذف "${confirmAction.guestName}"؟`,
            en: `Are you sure you want to delete "${confirmAction.guestName}"?`,
          },
        };
      case 'notify':
        return {
          title: { ar: 'إرسال إشعار', en: 'Send Notification' },
          description: {
            ar: `هل تريد إرسال إشعار WhatsApp لـ "${confirmAction.guestName}"؟`,
            en: `Do you want to send a WhatsApp notification to "${confirmAction.guestName}"?`,
          },
        };
      case 'rate':
        return {
          title: { ar: 'إرسال رابط التقييم', en: 'Send Rating Link' },
          description: {
            ar: `هل لعب العميل فعلاً؟ سيتم إرسال رابط التقييم الآن.`,
            en: `Has the guest finished playing? Sending rating link now.`,
          },
        };
      default:
        return {
          title: { ar: 'تأكيد', en: 'Confirm' },
          description: { ar: 'هل أنت متأكد؟', en: 'Are you sure?' },
        };
    }
  };

  if (guests.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-border bg-card/50 py-16">
        <Users className="mb-4 h-16 w-16 text-muted-foreground/50" />
        <p className="text-lg text-muted-foreground">لا يوجد ضيوف حالياً</p>
        <p className="text-sm text-muted-foreground/70">No guests currently</p>
      </div>
    );
  }

  return (
    <TooltipProvider>
      <div className="overflow-hidden rounded-xl border border-border bg-card/50 backdrop-blur-sm">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="text-right font-bold text-foreground">
                الرقم / Number
              </TableHead>
              <TableHead className="text-right font-bold text-foreground">
                الاسم / Name
              </TableHead>
              <TableHead className="text-right font-bold text-foreground">
                الجوال / Phone
              </TableHead>
              <TableHead className="text-center font-bold text-foreground">
                العدد / Party Size
              </TableHead>
              <TableHead className="text-center font-bold text-foreground">
                <div className="flex items-center justify-center gap-1">
                  <Clock className="h-4 w-4" />
                  <span>مدة الانتظار / Wait Time</span>
                </div>
              </TableHead>
              <TableHead className="text-center font-bold text-foreground">
                الحالة / Status
              </TableHead>
              <TableHead className="text-center font-bold text-foreground">
                الإجراءات / Actions
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {guests.map((guest, index) => {
              const waitTime = formatWaitTime(guest.addedAt);
              return (
                <TableRow
                  key={guest.id}
                  className="border-border transition-colors hover:bg-muted/30"
                >
                  <TableCell className="font-mono font-bold text-primary">
                    {index + 1}
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="font-semibold text-foreground">{guest.name}</p>
                      {guest.notes && (
                        <p className="text-xs text-muted-foreground">{guest.notes}</p>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="font-mono text-muted-foreground" dir="ltr">
                    {guest.phone || '-'}
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span className="font-bold">{guest.groupSize}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex flex-col items-center">
                      <span className="font-medium text-accent">{waitTime.ar}</span>
                      <span className="text-xs text-muted-foreground">{waitTime.en}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <StatusDropdown
                      status={guest.status}
                      onStatusChange={(status) => onStatusChange(guest.id, status)}
                    />
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center justify-center gap-1">
                      {/* Notify - Blue */}
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 text-blue-400 hover:bg-blue-500/20 hover:text-blue-300"
                            onClick={(e) => {
                              e.stopPropagation();
                              setConfirmAction({
                                type: 'notify',
                                guestId: guest.id,
                                guestName: guest.name,
                              });
                            }}
                          >
                            <MessageCircle className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>إرسال WhatsApp / Send WhatsApp</p>
                        </TooltipContent>
                      </Tooltip>

                      {/* Rate Us - Gold Star */}
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 text-amber-400 hover:bg-amber-500/20 hover:text-amber-300"
                            onClick={(e) => {
                              e.stopPropagation();
                              setConfirmAction({
                                type: 'rate',
                                guestId: guest.id,
                                guestName: guest.name,
                              });
                            }}
                          >
                            <Star className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>تقييم / Rate Us</p>
                        </TooltipContent>
                      </Tooltip>

                      {/* Delete - Red */}
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 text-red-400 hover:bg-red-500/20 hover:text-red-300"
                            onClick={(e) => {
                              e.stopPropagation();
                              setConfirmAction({
                                type: 'delete',
                                guestId: guest.id,
                                guestName: guest.name,
                              });
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>حذف / Delete</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      <ConfirmationModal
        open={confirmAction !== null}
        onOpenChange={(open) => !open && setConfirmAction(null)}
        onConfirm={executeAction}
        title={getConfirmationText().title}
        description={getConfirmationText().description}
        variant={confirmAction?.type === 'delete' ? 'destructive' : 'default'}
      />
    </TooltipProvider>
  );
}
