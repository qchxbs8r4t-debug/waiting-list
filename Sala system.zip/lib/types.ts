export type GuestStatus = 'waiting' | 'played' | 'canceled' | 'switched';

export interface Guest {
  id: string;
  name: string;
  phone: string;
  groupSize: number;
  addedAt: number;
  status: GuestStatus;
  notes?: string;
}

export const STATUS_LABELS: Record<GuestStatus, { ar: string; en: string }> = {
  waiting: { ar: 'انتظار', en: 'Waiting' },
  played: { ar: 'تم اللعب', en: 'Played' },
  canceled: { ar: 'ملغي', en: 'Canceled' },
  switched: { ar: 'تبديل للبولينج', en: 'Switch to Bowling' },
};

export const STATUS_COLORS: Record<GuestStatus, string> = {
  waiting: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  played: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  canceled: 'bg-red-500/20 text-red-400 border-red-500/30',
  switched: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
};
