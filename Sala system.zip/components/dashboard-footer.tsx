'use client';

import { Heart } from 'lucide-react';

export function DashboardFooter() {
  return (
    <footer className="fixed inset-x-0 bottom-0 z-[1000] border-t border-border bg-card/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-center px-4 py-3">
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <span>مدعوم بواسطة</span>
          <Heart className="h-4 w-4 fill-red-500 text-red-500" />
          <span className="font-semibold text-foreground">راكان بن سعد</span>
          <span className="text-muted-foreground/60">|</span>
          <span>Powered by</span>
          <span className="font-semibold text-foreground">Rakan Bin Saad</span>
        </p>
      </div>
    </footer>
  );
}
