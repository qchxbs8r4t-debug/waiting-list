'use client';

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, Clock, CheckCircle, XCircle, ArrowRightLeft } from 'lucide-react';
import type { GuestStatus } from '@/lib/types';
import { STATUS_LABELS, STATUS_COLORS } from '@/lib/types';

interface StatusDropdownProps {
  status: GuestStatus;
  onStatusChange: (status: GuestStatus) => void;
}

const STATUS_ICONS: Record<GuestStatus, React.ReactNode> = {
  waiting: <Clock className="h-3.5 w-3.5" />,
  played: <CheckCircle className="h-3.5 w-3.5" />,
  canceled: <XCircle className="h-3.5 w-3.5" />,
  switched: <ArrowRightLeft className="h-3.5 w-3.5" />,
};

export function StatusDropdown({ status, onStatusChange }: StatusDropdownProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-sm font-medium transition-all hover:opacity-80 ${STATUS_COLORS[status]}`}
          onClick={(e) => e.stopPropagation()}
        >
          {STATUS_ICONS[status]}
          <span>{STATUS_LABELS[status].ar}</span>
          <span className="text-xs opacity-70">/ {STATUS_LABELS[status].en}</span>
          <ChevronDown className="h-3.5 w-3.5 opacity-60" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="start"
        className="z-[9999] min-w-[200px] border-border bg-popover"
        onClick={(e) => e.stopPropagation()}
      >
        {(Object.keys(STATUS_LABELS) as GuestStatus[]).map((statusOption) => (
          <DropdownMenuItem
            key={statusOption}
            onClick={(e) => {
              e.stopPropagation();
              onStatusChange(statusOption);
            }}
            className={`flex cursor-pointer items-center gap-2 ${
              status === statusOption ? 'bg-accent' : ''
            }`}
          >
            <Badge
              variant="outline"
              className={`${STATUS_COLORS[statusOption]} border`}
            >
              {STATUS_ICONS[statusOption]}
            </Badge>
            <div className="flex flex-col">
              <span className="font-medium">{STATUS_LABELS[statusOption].ar}</span>
              <span className="text-xs text-muted-foreground">
                {STATUS_LABELS[statusOption].en}
              </span>
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
