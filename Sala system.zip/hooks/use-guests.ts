'use client';

import { useState, useEffect, useCallback } from 'react';
import type { Guest, GuestStatus } from '@/lib/types';

const STORAGE_KEY = 'sala_laser_tag_guests';
const BACKUP_KEY = 'sala_laser_tag_backup';

export function useGuests() {
  const [guests, setGuests] = useState<Guest[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setGuests(parsed);
      } catch {
        console.error('Failed to parse stored guests');
      }
    }
    setIsLoaded(true);
  }, []);

  // Save to localStorage whenever guests change
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(guests));
    }
  }, [guests, isLoaded]);

  const addGuest = useCallback((guest: Omit<Guest, 'id' | 'addedAt' | 'status'>) => {
    const newGuest: Guest = {
      ...guest,
      id: crypto.randomUUID(),
      addedAt: Date.now(),
      status: 'waiting',
    };
    setGuests((prev) => [...prev, newGuest]);
  }, []);

  const updateGuestStatus = useCallback((id: string, status: GuestStatus) => {
    setGuests((prev) =>
      prev.map((guest) => (guest.id === id ? { ...guest, status } : guest))
    );
  }, []);

  const deleteGuest = useCallback((id: string) => {
    setGuests((prev) => prev.filter((guest) => guest.id !== id));
  }, []);

  const resetShift = useCallback(() => {
    // Backup current data before reset
    localStorage.setItem(BACKUP_KEY, JSON.stringify(guests));
    setGuests([]);
  }, [guests]);

  const restoreData = useCallback(() => {
    const backup = localStorage.getItem(BACKUP_KEY);
    if (backup) {
      try {
        const parsed = JSON.parse(backup);
        setGuests(parsed);
        return true;
      } catch {
        return false;
      }
    }
    return false;
  }, []);

  // Check if phone number already exists in today's list
  const checkDuplicatePhone = useCallback((phone: string): boolean => {
    if (!phone.trim()) return false;
    const normalizedPhone = phone.trim().replace(/\D/g, '');
    return guests.some((g) => {
      const existingPhone = g.phone?.replace(/\D/g, '');
      return existingPhone && existingPhone === normalizedPhone;
    });
  }, [guests]);

  // Sort by wait duration (longest waiting first) - only waiting guests at top
  const sortedGuests = [...guests].sort((a, b) => {
    // Waiting guests come first
    if (a.status === 'waiting' && b.status !== 'waiting') return -1;
    if (a.status !== 'waiting' && b.status === 'waiting') return 1;
    // Among waiting guests, sort by wait time (oldest first)
    if (a.status === 'waiting' && b.status === 'waiting') {
      return a.addedAt - b.addedAt;
    }
    // Non-waiting guests sorted by most recent
    return b.addedAt - a.addedAt;
  });

  return {
    guests: sortedGuests,
    isLoaded,
    addGuest,
    updateGuestStatus,
    deleteGuest,
    resetShift,
    restoreData,
    checkDuplicatePhone,
    totalWaiting: guests.filter((g) => g.status === 'waiting').length,
    totalPlayed: guests.filter((g) => g.status === 'played').length,
    totalGuests: guests.length,
  };
}
