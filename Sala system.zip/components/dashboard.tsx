'use client';

import { useState, useEffect, useCallback } from 'react';
import { Plus } from 'lucide-react';
import { useGuests } from '@/hooks/use-guests';
import { DashboardHeader } from './dashboard-header';
import { DashboardFooter } from './dashboard-footer';
import { GuestTable } from './guest-table';
import { AddGuestModal } from './add-guest-modal';
import { Spinner } from '@/components/ui/spinner';
import { Button } from '@/components/ui/button';

export function Dashboard() {
  const {
    guests,
    isLoaded,
    addGuest,
    updateGuestStatus,
    deleteGuest,
    resetShift,
    restoreData,
    checkDuplicatePhone,
    totalWaiting,
    totalPlayed,
    totalGuests,
  } = useGuests();

  const [showAddModal, setShowAddModal] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Update waiting times every minute
  const [, setTick] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => setTick((t) => t + 1), 60000);
    return () => clearInterval(interval);
  }, []);

  const handleZoomIn = useCallback(() => {
    setZoom((prev) => Math.min(prev + 0.1, 1.5));
  }, []);

  const handleZoomOut = useCallback(() => {
    setZoom((prev) => Math.max(prev - 0.1, 0.5));
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  }, []);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  if (!isLoaded) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Spinner className="h-12 w-12 text-primary" />
          <p className="text-lg text-muted-foreground">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <DashboardHeader
        totalWaiting={totalWaiting}
        totalPlayed={totalPlayed}
        totalGuests={totalGuests}
        onResetShift={resetShift}
        onRestoreData={restoreData}
        zoom={zoom}
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        isFullscreen={isFullscreen}
        onToggleFullscreen={toggleFullscreen}
      />

      <main
        className="mx-auto w-full max-w-7xl flex-1 p-4 pb-20"
        style={{ transform: `scale(${zoom})`, transformOrigin: 'top center' }}
      >
        <GuestTable
          guests={guests}
          onStatusChange={updateGuestStatus}
          onDelete={deleteGuest}
        />
      </main>

      <DashboardFooter />

      {/* Floating Action Button */}
      <Button
        onClick={() => setShowAddModal(true)}
        className="fixed bottom-24 right-6 z-[9998] h-16 w-16 rounded-full bg-gradient-to-br from-primary to-secondary shadow-2xl hover:opacity-90 hover:shadow-primary/50"
        aria-label="إضافة ضيف جديد / Add New Guest"
      >
        <Plus className="h-8 w-8 text-white" />
      </Button>

      <AddGuestModal
        open={showAddModal}
        onOpenChange={setShowAddModal}
        onAdd={addGuest}
        checkDuplicatePhone={checkDuplicatePhone}
      />
    </div>
  );
}
