'use client';

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { UserPlus, AlertTriangle } from 'lucide-react';

interface AddGuestModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdd: (guest: { name: string; phone: string; groupSize: number; notes?: string }) => void;
  checkDuplicatePhone: (phone: string) => boolean;
}

export function AddGuestModal({ open, onOpenChange, onAdd, checkDuplicatePhone }: AddGuestModalProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [groupSize, setGroupSize] = useState('1');
  const [notes, setNotes] = useState('');
  const [showDuplicateWarning, setShowDuplicateWarning] = useState(false);
  const [pendingGuest, setPendingGuest] = useState<{ name: string; phone: string; groupSize: number; notes?: string } | null>(null);

  const resetForm = () => {
    setName('');
    setPhone('');
    setGroupSize('1');
    setNotes('');
    setPendingGuest(null);
    setShowDuplicateWarning(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const guestData = {
      name: name.trim(),
      phone: phone.trim(),
      groupSize: parseInt(groupSize) || 1,
      notes: notes.trim() || undefined,
    };

    // Check for duplicate phone number
    if (phone.trim() && checkDuplicatePhone(phone.trim())) {
      setPendingGuest(guestData);
      setShowDuplicateWarning(true);
      return;
    }

    // No duplicate, add directly
    onAdd(guestData);
    resetForm();
    onOpenChange(false);
  };

  const handleConfirmDuplicate = () => {
    if (pendingGuest) {
      onAdd(pendingGuest);
      resetForm();
      onOpenChange(false);
    }
  };

  const handleCancelDuplicate = () => {
    setShowDuplicateWarning(false);
    setPendingGuest(null);
  };

  return (
    <>
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="z-[9999] border-border bg-card text-card-foreground sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/20">
              <UserPlus className="h-5 w-5 text-primary" />
            </div>
            <div>
              <span className="block">إضافة ضيف جديد</span>
              <span className="block text-sm font-normal text-muted-foreground">
                Add New Guest
              </span>
            </div>
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-foreground">
              الاسم / Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="أدخل اسم الضيف"
              className="border-border bg-input text-foreground placeholder:text-muted-foreground"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone" className="text-foreground">
              رقم الجوال / Phone
            </Label>
            <Input
              id="phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="05XXXXXXXX"
              className="border-border bg-input text-foreground placeholder:text-muted-foreground"
              dir="ltr"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="groupSize" className="text-foreground">
              عدد الأفراد / Group Size
            </Label>
            <Input
              id="groupSize"
              type="number"
              min="1"
              max="20"
              value={groupSize}
              onChange={(e) => setGroupSize(e.target.value)}
              className="border-border bg-input text-foreground"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes" className="text-foreground">
              ملاحظات / Notes
            </Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="ملاحظات إضافية..."
              className="border-border bg-input text-foreground placeholder:text-muted-foreground"
              rows={2}
            />
          </div>

          <div className="flex gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1 border-border text-foreground hover:bg-muted"
            >
              إلغاء / Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              إضافة / Add
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>

    {/* Duplicate Phone Warning Dialog */}
    <Dialog open={showDuplicateWarning} onOpenChange={setShowDuplicateWarning}>
      <DialogContent className="z-[10000] border-amber-500/50 bg-card text-card-foreground sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-500/20">
              <AlertTriangle className="h-5 w-5 text-amber-400" />
            </div>
            <div>
              <span className="block text-amber-400">تحذير: رقم مكرر</span>
              <span className="block text-sm font-normal text-amber-400/70">
                Warning: Duplicate Number
              </span>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <p className="text-center text-foreground leading-relaxed">
            هذا الرقم مسجل بالفعل في قائمة اليوم.
            <br />
            هل أنت متأكد من رغبتك في إضافته مرة أخرى؟
          </p>
          <p className="text-center text-sm text-muted-foreground leading-relaxed">
            This number is already registered today.
            <br />
            Are you sure you want to add it again?
          </p>
        </div>

        <div className="flex gap-3 pt-2">
          <Button
            type="button"
            variant="outline"
            onClick={handleCancelDuplicate}
            className="flex-1 border-border text-foreground hover:bg-muted"
          >
            إلغاء / Cancel
          </Button>
          <Button
            type="button"
            onClick={handleConfirmDuplicate}
            className="flex-1 bg-amber-500 text-white hover:bg-amber-600"
          >
            نعم، أضف / Yes, Add
          </Button>
        </div>
      </DialogContent>
    </Dialog>
    </>
  );
}
