'use client';

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface ConfirmationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
  title?: { ar: string; en: string };
  description?: { ar: string; en: string };
  confirmText?: { ar: string; en: string };
  cancelText?: { ar: string; en: string };
  variant?: 'default' | 'destructive';
}

export function ConfirmationModal({
  open,
  onOpenChange,
  onConfirm,
  title = { ar: 'تأكيد العملية', en: 'Confirm Action' },
  description = {
    ar: 'هل أنت متأكد من تنفيذ هذا الأمر؟',
    en: 'Are you sure you want to proceed?',
  },
  confirmText = { ar: 'تأكيد', en: 'Confirm' },
  cancelText = { ar: 'إلغاء', en: 'Cancel' },
  variant = 'default',
}: ConfirmationModalProps) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="z-[9999] border-border bg-card text-card-foreground">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-xl font-bold">
            <span className="block text-right">{title.ar}</span>
            <span className="block text-left text-base font-normal text-muted-foreground">
              {title.en}
            </span>
          </AlertDialogTitle>
          <AlertDialogDescription className="space-y-1">
            <span className="block text-right text-base">{description.ar}</span>
            <span className="block text-left text-sm text-muted-foreground">
              {description.en}
            </span>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex-row-reverse gap-2">
          <AlertDialogCancel className="m-0 border-border bg-muted text-foreground hover:bg-muted/80">
            <span>{cancelText.ar}</span>
            <span className="mx-1 text-muted-foreground">/</span>
            <span className="text-muted-foreground">{cancelText.en}</span>
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            className={
              variant === 'destructive'
                ? 'm-0 bg-destructive text-destructive-foreground hover:bg-destructive/90'
                : 'm-0 bg-primary text-primary-foreground hover:bg-primary/90'
            }
          >
            <span>{confirmText.ar}</span>
            <span className="mx-1 text-primary-foreground/60">/</span>
            <span className="text-primary-foreground/80">{confirmText.en}</span>
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
