'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  RotateCcw,
  Database,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  Target,
  Users,
  CheckCircle,
} from 'lucide-react';
import { ConfirmationModal } from './confirmation-modal';

interface DashboardHeaderProps {
  totalWaiting: number;
  totalPlayed: number;
  totalGuests: number;
  onResetShift: () => void;
  onRestoreData: () => void;
  zoom: number;
  onZoomIn: () => void;
  onZoomOut: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
}

export function DashboardHeader({
  totalWaiting,
  totalPlayed,
  totalGuests,
  onResetShift,
  onRestoreData,
  zoom,
  onZoomIn,
  onZoomOut,
  isFullscreen,
  onToggleFullscreen,
}: DashboardHeaderProps) {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showRestoreConfirm, setShowRestoreConfirm] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-[1000] border-b border-border bg-card/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          {/* Logo & Title */}
          <div className="flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-secondary shadow-lg">
              <Target className="h-7 w-7 text-white" />
            </div>
            <div>
              <h1 className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-xl font-bold text-transparent">
                SALA Laser Tag
              </h1>
              <p className="text-sm text-muted-foreground">
                لوحة التحكم التشغيلية / Operational Dashboard
              </p>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="hidden items-center gap-3 md:flex">
            <div className="flex items-center gap-2 rounded-lg bg-amber-500/10 px-4 py-2">
              <Users className="h-5 w-5 text-amber-400" />
              <div className="text-right">
                <p className="text-lg font-bold text-amber-400">{totalWaiting}</p>
                <p className="text-xs text-amber-400/70">انتظار</p>
              </div>
            </div>
            <div className="flex items-center gap-2 rounded-lg bg-emerald-500/10 px-4 py-2">
              <CheckCircle className="h-5 w-5 text-emerald-400" />
              <div className="text-right">
                <p className="text-lg font-bold text-emerald-400">{totalPlayed}</p>
                <p className="text-xs text-emerald-400/70">تم اللعب</p>
              </div>
            </div>
            <div className="flex items-center gap-2 rounded-lg bg-primary/10 px-4 py-2">
              <Users className="h-5 w-5 text-primary" />
              <div className="text-right">
                <p className="text-lg font-bold text-primary">{totalGuests}</p>
                <p className="text-xs text-primary/70">إجمالي</p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={() => setShowResetConfirm(true)}
              className="border-border text-foreground hover:bg-muted"
            >
              <RotateCcw className="ml-2 h-4 w-4" />
              <span className="hidden lg:inline">تصفير الدوام</span>
            </Button>

            <Button
              variant="outline"
              onClick={() => setShowRestoreConfirm(true)}
              className="border-border text-foreground hover:bg-muted"
            >
              <Database className="ml-2 h-4 w-4" />
              <span className="hidden lg:inline">استرجاع</span>
            </Button>

            {/* Zoom & Fullscreen Controls - Top Right */}
            <div className="flex items-center gap-1 rounded-lg border border-border bg-muted/50 p-1">
              <Button
                size="icon"
                variant="ghost"
                onClick={onZoomOut}
                className="h-8 w-8"
                disabled={zoom <= 0.5}
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <span className="w-12 text-center text-sm font-medium">
                {Math.round(zoom * 100)}%
              </span>
              <Button
                size="icon"
                variant="ghost"
                onClick={onZoomIn}
                className="h-8 w-8"
                disabled={zoom >= 1.5}
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
              <div className="mx-1 h-6 w-px bg-border" />
              <Button
                size="icon"
                variant="ghost"
                onClick={onToggleFullscreen}
                className="h-8 w-8"
              >
                {isFullscreen ? (
                  <Minimize2 className="h-4 w-4" />
                ) : (
                  <Maximize2 className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <ConfirmationModal
        open={showResetConfirm}
        onOpenChange={setShowResetConfirm}
        onConfirm={() => {
          onResetShift();
          setShowResetConfirm(false);
        }}
        title={{ ar: 'تصفير الدوام', en: 'Reset Shift' }}
        description={{
          ar: 'سيتم حذف جميع البيانات الحالية وحفظها كنسخة احتياطية. هل أنت متأكد؟',
          en: 'All current data will be cleared and backed up. Are you sure?',
        }}
        variant="destructive"
      />

      <ConfirmationModal
        open={showRestoreConfirm}
        onOpenChange={setShowRestoreConfirm}
        onConfirm={() => {
          onRestoreData();
          setShowRestoreConfirm(false);
        }}
        title={{ ar: 'استرجاع البيانات', en: 'Restore Data' }}
        description={{
          ar: 'سيتم استرجاع البيانات من آخر نسخة احتياطية. هل أنت متأكد؟',
          en: 'Data will be restored from the last backup. Are you sure?',
        }}
      />
    </>
  );
}
